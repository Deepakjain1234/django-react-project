from django.apps import AppConfig


class EmployeeappConfig(AppConfig):
    name = 'EmployeeApp'
